import boto3
from boto3.dynamodb.conditions import Key, Attr
import json
import os
import uuid
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table_name = os.environ['TABLE_NAME']
table = dynamodb.Table(table_name)


def get_order(key):
    if "order_id" in key and "customer_id" in key:
        response = table.get_item(
            Key=key
        )
        return response["Item"]


def create_order(event):
    if "order_details" in event:
        order_data = event['order_details']
        order_id = str(uuid.uuid4())
        order_data['order_id'] = order_id
        order_data['order_status'] = "submitted_created"
        order_data['order_status_reason'] = "Order created upon a client initial request"

        time_now = datetime.now().isoformat()
        order_data['created_at'] = time_now
        order_data['updated_at'] = time_now

        table.put_item(Item=order_data)
        return order_data


def update_order(order):
    time_now = datetime.now().isoformat()
    order['updated_at'] = time_now

    table.put_item(Item=order)
    return order
