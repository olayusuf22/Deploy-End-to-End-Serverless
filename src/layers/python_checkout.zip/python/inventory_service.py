import random

mock_api_responses = [
    {
        "status": 200,
        "message": "Inventory Update Successful",
    },
    {
        "status": 500,
        "message": "Internal Server Error",
    },
    {
        "status": 503,
        "message": "Service Unavailable. Try again",
    }
]


def send_request(request):
    return random.choice(mock_api_responses)