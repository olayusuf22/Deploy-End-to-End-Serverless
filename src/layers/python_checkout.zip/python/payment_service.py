import random
import uuid

mock_api_responses = [
    {
        "status": 200,
        "message": "Payment successful",
        "txn_id": str(uuid.uuid4()),
        "txn_status": "paid",
        "txn_amount": "5.00",
    },
    {
        "status": 400,
        "message": "Invalid payment details",
    },
    {
        "status": 503,
        "message": "Service unavailable. Try again",
    },
    {
        "status": 500,
        "message": "Internal Server Error",
    }
]


def send_request(request):
    return random.choice(mock_api_responses)


def refund_payment(request):
    return {
        "txn_id": str(uuid.uuid4()),
        "txn_status": "refunded",
        "txn_amount": "5.00",
    }

